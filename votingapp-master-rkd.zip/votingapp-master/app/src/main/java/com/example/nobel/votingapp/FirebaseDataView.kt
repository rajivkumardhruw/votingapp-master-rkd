package com.example.nobel.votingapp


data class FirebaseDataView(val Part1:String,val Part2:String,val Part3:String,val Part4:String,val vp1:String,val vp2:String,val vp3:String,val vp4:String)