package com.example.nobel.votingapp

data class FDcell(val part1:String,val part2:String,val part3:String,val part4:String,var vp1:Int,var vp2:Int,var vp3:Int,var vp4:Int)